<?php
$name='Sun-ExtA';
$type='TTF';
$desc=array (
  'CapHeight' => 684,
  'XHeight' => 453,
  'FontBBox' => '[-973 -301 2074 1078]',
  'Flags' => 4,
  'Ascent' => 930,
  'Descent' => -141,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$unitsPerEm=256;
$up=-86;
$ut=47;
$strp=254;
$strs=47;
$ttffile='D:/Programs/EasyPHP/data/localweb/sma/sma/third_party/MPDF/ttfonts/Sun-ExtA.ttf';
$TTCfontID='0';
$originalsize=22993540;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='sun-exta';
$panose=' 0 0 2 1 6 0 3 1 1 1 1 1';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 859, -141, 0
// usWinAscent/usWinDescent = 930, -141
// hhea Ascent/Descent/LineGap = 930, -141, 141
$useOTL=0x0000;
$rtlPUAstr='';
?>